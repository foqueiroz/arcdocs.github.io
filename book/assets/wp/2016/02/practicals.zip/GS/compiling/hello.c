/* Simple "hello world"-type program written in C 
written by ANR */

#include <stdio.h>

int main ()
{
printf ("You have sucessfully compiled and run a C program !\n");
}
