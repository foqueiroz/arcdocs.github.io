/* simple "hello world"-type program written in C++" 
Written by ANR */

#include <iostream>
int main() {
  std::cout <<"You have successfully compiled and run a C++ program" << std::endl;
  return 0;
}
