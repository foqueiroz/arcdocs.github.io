/* Simple "hello world"-type program written in C 
written by ANR */

#include <stdio.h>
#include <stdlib.h>

/* To shorten example, not using argp */
int main ()
{
  char *host, name[50];

  host = getenv("HOSTNAME");

  printf ("This program is running on %s.\n", host);
  printf ("Please enter your name\n");
  fflush(stdout);
  scanf ("%s", &name);
 printf ("Hello %s.\n", name); 
  printf ("I apologise for not making a more interesting practical\n");
  printf ("Goodbye\n");

}
