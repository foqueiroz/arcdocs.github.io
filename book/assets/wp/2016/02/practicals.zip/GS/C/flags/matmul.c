/*
Program that carries out matrix multiplication A = B * C, where A and C are
column vectors and B is a square 2D matrix of dimensions equal to the dimensions
of A and C.
Calculation is performed by row, by column or by a library routine.
Code performs differntly based upon compiler options used.
This code, when autoparallelised uses the multithreaded perfomance library.
Code is a simplifed version of code originally written by Ruud van der Pas as
part of the "Suntune Labs" and is used by permission of Sun Microsystems.
Modifications have been made by ANR.
The option -dalign is required to compile with the sun performance libray.
To link with the sun performance library, use -xlic_lib=sunperf
*/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <float.h>
#include <sys/time.h>


#define MIN(A,B) ( (A) < (B) ? (A) : (B) )
#define B(i,j) b[(i)*n+(j)]

int mmax=4096;
int nmax=4096;

/* function definitions */
void dummy(double *x);

int check_results(char *comment, int m, int n, double *a, double *ref);

void init_data(int m, int n, double *b, double *c, double *ref);

void init_timer(int *nthreads);

void mxv_col(int m, int n, double *a, double *b, double *c);

void mxv_lib(int m, int n, double *a, double *b, double *c);

void mxv_row(int m, int n, double *a, double *b, double *c);

void dgemv_(char *trans, int *m, int *n, double *alpha, double *a, int *lda, double *x, int *incx, double *beta, double *y, int *incy);

void timer(int *nthreads);

double secnds(void);



#define LEN_HEADER 132

int main(int argc, char *argv[])
{
   double *a;
   double *b;
   double *c;
   double *ref;

   int    m, n, krep, kr;

   double ts, te_col, te_row, te_lib;
   double tt_row = 0.0, tt_col = 0.0, tt_lib = 0.0;
   float  perf_col, perf_row, perf_lib, mflops, memsize;

 printf("   M    N   Memsize(K) t(row)  t(col)  t(lib) perf(row) perf(col) perf(lib)\n");

 tt_row = 0.0;
 tt_col = 0.0;
 tt_lib = 0.0;
 
 m=16;
 n=16;
 
 while ( m <= mmax && n <= nmax) 
 {
 krep = mmax*nmax/m/n;
 
 
       if ( (a=(double *)malloc(m*sizeof(double))) == NULL ) {
        perror("array a");
        exit(-1);
      }
      if ( (b=(double *)malloc(m*n*sizeof(double))) == NULL ) {
        perror("array b");
        exit(-1);
      }
      if ( (c=(double *)malloc(n*sizeof(double))) == NULL ) {
        perror("array c");
        exit(-1);
      }
      if ( (ref=(double *)malloc(m*sizeof(double))) == NULL ) {
        perror("array ref");
        exit(-1);
      }

      (void) init_data(m, n, b, c, ref);

      mflops   = 2.0*m*n*1.0E-06;
      memsize  = sizeof(double)*(m+m*n+n)/1024.0; /*-- KByte --*/

      ts = secnds();
      for ( kr=0; kr < krep; kr++)
          (void) mxv_row(m, n, a, b, c);
      te_row   = secnds() - ts;
      perf_row = krep*mflops/te_row;
      tt_row  += te_row;

      if (check_results("mxv_row",m, n, a, ref) > 0 ) return(-2);
      
      ts = secnds();
      for ( kr=0; kr < krep; kr++)
          (void) mxv_col(m, n, a, b, c);
      te_col   = secnds() - ts;
      perf_col = krep*mflops/te_col;
      tt_col  += te_col;

      if (check_results("mxv_col",m, n, a, ref) > 0 ) return(-2);

      ts  = secnds();
      for ( kr=0; kr < krep; kr++)
          (void) mxv_lib(m, n, a, b, c);
      te_lib   = secnds() - ts;
      perf_lib = krep*mflops/te_lib;
      tt_lib  += te_lib;

      if (check_results("mxv_lib",m, n, a, ref) > 0 ) return(-2);

      printf("%4d %4d %9.2f  %7.2f %7.2f %7.2f  %8.2f %8.2f %8.2f\n",
             m,n,memsize,te_row,te_col,te_lib,perf_row,perf_col,perf_lib);
	     
   free(a);
   free(b);
   free(c);
   free(ref);

m = m * 2;
n = n * 2;
 
 }
}

void mxv_row(int m, int n, double *a, double *b, double *c)
{
   int i, j;
   double sum;

   for (i=0; i<m; i++)
   {
     sum = 0.0;
     for (j=0; j<n; j++)
       sum += B(i,j)*c[j];
     a[i] = sum;
   }
}

void mxv_col(int m, int n, double *a, double *b, double *c)
{
   int i, j;

   for (i=0; i<m; i++)
       a[i] = B(i,0)*c[0];

   for (j=1; j<n; j++)
   {
     (void) dummy(&a[j]);  /*-- Avoids loop interchange --*/
     for (i=0; i<m; i++)
       a[i] += B(i,j)*c[j];
   }
}


void mxv_lib(int m, int n, double *a, double *b, double *c)
{

/*-- This is needed for the Sun Performance Library routine DGEMV --*/

   char   transa = 'T';
   double alpha = 1.0, beta = 0.0;
   int    incc=1, inca=1, ldb;

/* y = alpha*A*x+beta*y */
/* a = alpha*B*c+beta*a */

      ldb = n;

      (void) dgemv_(&transa, &n, &m, &alpha, b, &ldb, c, &incc, &beta, a, &inca);

}
void init_data (int m, int n, double *b, double *c, double *ref)
{
   int i, j;

   for (j=0; j<n; j++)
      c[j] = 1.0;
   for (i=0; i<m; i++)
      for (j=0; j<n; j++)
         B(i,j) = i;
   for (i=0; i<m; i++)
      ref[i] = n*i;
}

int check_results(char *comment, int m, int n, double *a, double *ref)
{
   double relerr;
   int   i, errors = 0;
   char  *marker;
   double TOL   = 100.0 * DBL_EPSILON;
   double SMALL = 100.0 * DBL_MIN;

   if ( (marker=(char *)malloc(m*sizeof(char))) == NULL ) {
        perror("array marker");
        exit(-1);
   }

   for (i=0; i<m; i++)
   {
       if ( fabs(ref[i]) > SMALL )
       {
          relerr = fabs((a[i]-ref[i])/ref[i]);
       }
       else
       {
          relerr = fabs((a[i]-ref[i]));
       }
       if ( relerr <= TOL )
       {
          marker[i] = ' ';
       }
       else
       {
          errors++;
          marker[i] = '*';
       }
   }
   if ( errors > 0 )
   {
     printf("Routine: %s\n",comment);
     printf("Found %d differences in results for m=%d n=%d:\n",
             errors,m,n);
     for (i=0; i<m; i++)
         printf("\t%c a[%d]=%f ref[%d]=%f\n",marker[i],i,a[i],i,ref[i]);
   }
   return(errors);
}


void dummy(double *x)
{
}

time_t starttime = 0; 

double secnds()
{

  struct timeval ts; 

  double t;

  int err; 

  err = gettimeofday(&ts, NULL); 

  t = (double) (ts.tv_sec - starttime)  + (double) ts.tv_usec * 1.0e-6; 
 
  return t; 

}
