#$ -cwd -V
#$ -l h_rt=00:30:00
./array 10
