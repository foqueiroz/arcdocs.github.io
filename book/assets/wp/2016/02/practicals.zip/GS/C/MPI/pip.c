/* C Image processing example code.
 This example is based upon a casestudy exercise presented by EPCC.
 The program takes an image that has undergoe edge-detection
 and reconstructs the original image.
 This is physically analogous to solving the Poisson equation.
 Program uses 1D domain decomposistion, performing boundary swaps every
 iteration.
 Main program is written by ANR (with help of Jason Lander)
 Routines dataread and pgmwrite are written by David Henty, EPCC.
 Program will run on any number of processors that is a factor of 192, i.e.:
 1, 2, 3, 4, 6, 8, 12, 16 processors.
*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <sys/time.h>

#include <mpi.h>

#define XMAX 192
#define YMAX 360
#define NITERS 10000

void pgmwrite(char *filename, void *vx, int nx, int ny);
void dataread(char *filename, void *vx, int nx, int ny);
double secnds(void);

 
int main(int argc, char **argv){

  int i, j, iter; 
  double res, start, time;
  int m=192, n=360;
  float masterbuf[XMAX][YMAX];

  char *filename;
  char *output;
  
  float *buf;
  float *edge;
  float *old;
  float *new;
   
  int rank;
  int size;
  int dimx, dimy;
  int dims[1]={0};
  int periods[1]={0};
  int left, right;
  MPI_Comm RingComm;
  MPI_Request req;
  MPI_Status status;

/* Initialise MPI */

MPI_Init(&argc, &argv);
MPI_Comm_rank(MPI_COMM_WORLD, &rank);
MPI_Comm_size(MPI_COMM_WORLD, &size);

/* Set up arrays */
dimx=m/size;
dimy=n;

/* Read in data on process 0 */
if (rank == 0) {
  filename = "edge192x360.dat"; 
  dataread(filename, masterbuf, m, n); 
start=secnds();
}
/* Allocate arrays */
buf=(float *)malloc((dimx*dimy)*sizeof(float *));
edge=(float *)malloc((dimx+2)*(dimy+2)*sizeof(float *));
old=(float *)malloc((dimx+2)*(dimy+2)*sizeof(float *));
new=(float *)malloc((dimx+2)*(dimy+2)*sizeof(float *));
/* Create cartesian topology */
MPI_Dims_create(size,1, dims);
MPI_Cart_create(MPI_COMM_WORLD, 1, dims, periods, 0, &RingComm);
/* Find neighbours above and below */
MPI_Cart_shift(RingComm, 0, 1, &left, &right);
MPI_Scatter(&masterbuf, dimx*dimy, MPI_FLOAT, buf, dimx*dimy, MPI_FLOAT,0, MPI_COMM_WORLD);
  for (i=0; i<dimx+2; i++) {
    for (j=0; j<dimy+2; j++) {
      edge[i*(dimy+2)+j]=0.0;
    }
  }
  for (i=0; i<dimx; i++) {
    for (j=0; j<dimy; j++) {      
      edge[(i+1)*(dimy+2)+(j+1)]=buf[i*(dimy)+j];
    }
  }
  for (i=0; i<dimx+2; i++) {
    for (j=0; j<dimy+2; j++) {      
      old[i*(dimy+2)+j] = edge[i*(dimy+2)+j];
    }
  }
  for (iter=1; iter<=NITERS; iter++) {
MPI_Issend(&old[(dimx)*(dimy+2)+1],dimy, MPI_FLOAT, right, 1, RingComm, &req);
MPI_Recv(&old[1], dimy, MPI_FLOAT, left, 1, RingComm, &status);
MPI_Wait(&req, &status);
MPI_Issend(&old[(dimy+2)+1],dimy, MPI_FLOAT, left, 1, RingComm, &req);
MPI_Recv(&old[(dimx+1)*(dimy+2)+1], dimy, MPI_FLOAT, right, 1, RingComm, &status);
MPI_Wait(&req, &status);
for (i = 1; i<dimx+1; i++) {
    for (j = 1; j<dimy+1; j++) {
     new[i*(dimy+2)+j]=0.25*(old[(i-1)*(dimy+2)+j] + old[(i+1)*(dimy+2)+j] +
               old[i*(dimy+2)+j-1] + old[i*(dimy+2)+j+1] - edge[i*(dimy+2)+j]);
    }
}
for (i = 0; i<dimx+2; i++) {
    for (j = 0; j<dimy+2; j++) {
      old[i*(dimy+2)+j]=new[i*(dimy+2)+j];
    }
}
} /* end k iterations */
  for (i=0; i<dimx; i++) {
    for (j=0; j<dimy; j++) {
      buf[(i*dimy)+j]=new[(i+1)*(dimy+2)+(j+1)];
    }
  }
MPI_Gather(buf, dimx*dimy, MPI_FLOAT, &masterbuf, dimx*dimy, MPI_FLOAT, 0, 
          MPI_COMM_WORLD);
/* Output image */
if (rank == 0 ) 
{
time=secnds() - start;
output="output.pgm";
pgmwrite(output, masterbuf, m,n);
printf("Time for %d iterations on %d processors = %f secs\n", NITERS, size, time);
}  
MPI_Finalize();
}

void dataread(char *filename, void *vx, int nx, int ny)
{ 
  FILE *fp;
  int nxt, nyt, i, j, t;
  float *x = (float *) vx;
  
  if (NULL == (fp = fopen(filename,"r")))
  {
    fprintf(stderr, "datread: cannot open <%s>\n", filename);
    exit(-1);
  }
  fscanf(fp,"%d %d",&nxt,&nyt);
  if (nx != nxt || ny != nyt)
  {
    fprintf(stderr,
            "datread: size mismatch, (nx,ny) = (%d,%d) expected (%d,%d)\n",
            nxt, nyt, nx, ny);
    exit(-1);
  }

  /*
   *  Must cope with the fact that the storage order of the data file
   *  is not the same as the storage of a C array, hence the pointer
   *  arithmetic to access x[i][j].
   */

  for (j=0; j<ny; j++)
  {
    for (i=0; i<nx; i++)
    {
      fscanf(fp,"%d", &t);
      x[j+ny*i] = t;
    }
  }

  fclose(fp);
}


/*
 *  Routine to write a PGM image file from a 2D floating point array
 *  x[nx][ny]. Because of the way C handles (or fails to handle!)
 *  multi-dimensional arrays we have to cast the pointer to void.
 */

void pgmwrite(char *filename, void *vx, int nx, int ny)
{
  FILE *fp;

  int i, j, k, grey;

  float xmin, xmax, tmp;
  float thresh = 255.0;

  float *x = (float *) vx;

  if (NULL == (fp = fopen(filename,"w")))
  {
    fprintf(stderr, "pgmwrite: cannot create <%s>\n", filename);
    exit(-1);
  }

  /*
   *  Find the max and min absolute values of the array
   */

  xmin = fabs(x[0]);
  xmax = fabs(x[0]);

  for (i=0; i < nx*ny; i++)
  {
    if (fabs(x[i]) < xmin) xmin = fabs(x[i]);
    if (fabs(x[i]) > xmax) xmax = fabs(x[i]);
  }

  fprintf(fp, "P2\n");
  fprintf(fp, "# Written by pgmwrite\n");
  fprintf(fp, "%d %d\n", nx, ny);
  fprintf(fp, "%d\n", (int) thresh);

  k = 0;

  for (j=0; j< ny; j++)
  {
    for (i=0; i < nx; i++)
    {
      /*
       *  Access the value of x[i][j]
       */

      tmp = x[j+ny*i];

      /*
       *  Scale the value appropriately so it lies between 0 and thresh
       */

      if (xmin < 0 || xmax > thresh)
      {
        tmp = (int) ((thresh*((fabs(tmp-xmin))/(xmax-xmin))) + 0.5);
      }
      else
      {
        tmp = (int) (fabs(tmp) + 0.5);
      }

      /*
       *  Increase the contrast by boosting the lower values
       */
     
      grey = thresh * sqrt(tmp/thresh);

      fprintf(fp, "%3d ", grey);

      if (0 == (k+1)%17) fprintf(fp, "\n");

      k++;
    }
  }

  if (0 != k%17) fprintf(fp, "\n");
  fclose(fp);
}

time_t starttime = 0; 

double secnds()
{

  struct timeval ts; 

  double t;

  int err; 

  err = gettimeofday(&ts, NULL); 

  t = (double) (ts.tv_sec - starttime)  + (double) ts.tv_usec * 1.0e-6; 
 
  return t; 

}


