/* C image processing example code.
The program takes an image that has undergone edge-detection
and reconstructs the original image.
This is physically analogous to solving the Poisson equation.
Program uses parallel for directive for loops.
Original code written by Mark Bull, EPCC.
OpenMP directives added by ANR.
*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <limits.h>
#include <sys/time.h>

#define NXMAX 1000
#define NYMAX 1000
#define NITERS 10000

void new2old(void);
void jacobistep(void);
double residue(void); 
void pgmwrite (int);
void dataread(char *);
double secnds(void);

  

float xold[NYMAX+2][NXMAX+2], xnew[NYMAX+2][NXMAX+2], 
    b[NYMAX+2][NXMAX+2], btmp[NYMAX][NXMAX]; 
  
int nx, ny;
  





int main(int argv, char **argc){

  int i, j, iter; 
  double res, start, time;

  /* Read data file into temporary storage */ 

  char *filename; 

  filename = "edge192x360.dat"; 

  dataread(filename); 

  if (nx==0 || ny ==0) exit(1); 

  printf("Problem size is %d x %d\n",nx,ny); 

  /*  Copy into array with halos */  


  for (j=0; j<ny+2; j++) {
    for (i=0; i<nx+2; i++) {
      
      b[j][i]=0.0;

    }
  }


  for (j=0; j<ny; j++) {
    for (i=0; i<nx; i++) {
      
      b[j+1][i+1]=btmp[j][i];

    }
  }
  
  /* Initialise solution xnew */ 
  for (j=1; j<ny+1; j++) {
    for (i=1; i<nx+1; i++) {
      
      xnew[j][i] = b[j][i];
      
    }
  }
  
  res = residue(); 
		  
  printf("Initial residue = %f\n",res);
  
  start = secnds(); 

  for (iter=0; iter<NITERS; iter++) {

    new2old(); 

    jacobistep(); 

    res = residue(); 
    
  } 

  time = secnds() - start;  

  printf("Final residue = %f\n",res);  
  printf("\n");
  printf("Time =  %f\n",(float) time);  

  pgmwrite(iter); 

}

void new2old(void){

  int i,j; 
#pragma omp parallel for default(none) \
private(i,j) shared(ny,nx,xold,xnew)
  for (j=1; j<ny+1; j++) {
    for (i=1; i<nx+1; i++) {
      
      xold[j][i] = xnew[j][i];
      
    }
  }


}


void jacobistep(void){

  int i,j;

#pragma omp parallel for default(none) private(i,j) shared(nx,ny,xold,xnew,b)
  for (j=1; j<ny+1; j++) {
    for (i=1; i<nx+1; i++) {
      
      xnew[j][i] = 0.25 * (xold[j][i+1] + xold[j][i-1] + xold[j-1][i] + 
			   xold[j+1][i] - b[j][i]);
      
    }
  }


}
double residue(void){ 

  double ressq=0.0, tmp; 
  int i,j;

#pragma omp parallel for \
default(none) reduction(+:ressq) private(i,j,tmp) shared(nx,ny,xnew,b)
  for (j=1; j<ny+1; j++) {
    for (i=1; i<nx+1; i++) {

      tmp = xnew[j][i+1] + xnew[j][i-1] + xnew[j-1][i] + xnew[j+1][i]
	- 4.0 * xnew[j][i]  - b[j][i];
      ressq += tmp*tmp;  

    }
  }

  return(sqrt(ressq)); 

}


void pgmwrite (int index){
  char cp[20];
  FILE *fp;
  int i,j;
  float xmax, xmin;  

  int grey[NYMAX+2][NXMAX+2]; 
  
  xmin = INT_MAX; 
  xmax = INT_MIN; 

  for (j=1;j<ny+1;j ++) {
    for (i=1;i<nx+1;i++) {
      if (xnew[j][i] < xmin) xmin = xnew[j][i]; 
      if (xnew[j][i] > xmax) xmax = xnew[j][i]; 
    }
  }

  if (xmin < 0.0 || xmax > 255.0) {

    for (j=1;j<ny+1;j ++) {
      for (i=1;i<nx+1;i++) {
	grey[j][i] = (int) (255.0 * (xnew[j][i]-xmin)/(xmax-xmin) + 0.5);
      }
    }

   }
  
  else {

    for (j=1;j<ny+1;j ++) {
      for (i=1;i<nx+1;i++) {
	grey[j][i] = (int) (xnew[j][i] + 0.5);
      }
    }

  } 

  if((fp=fopen("finalimage.pgm","w")) == NULL){
    fprintf(stderr, "Cannot open file %s\n",cp); exit(1); }
  fprintf(fp,"P2\n%.3d  %.3d\n255\n",nx,ny);
  
  for (j=1;j<ny+1;j ++) {
    for (i=1;i<nx+1;i++) {
      fprintf(fp,"%d\n",(int) grey[j][i]);
    }
  }
  fclose(fp);
  
}

void dataread(char *filename) { 
  FILE *fp;
  int i,j;
  
  fp = fopen(filename,"r");

  fscanf(fp,"%d %d",&nx,&ny);

  if (nx > NXMAX || ny > NYMAX) {
    fprintf(stderr, "Not enough space \n");
    nx = 0;
    ny = 0;
    return;
  }

  
  for (j=0; j<ny; j++) {
    for (i=0; i<nx; i++) {

      fscanf(fp,"%f",&btmp[j][i]); 

    }
  }

}

time_t starttime = 0; 

double secnds()
{

  struct timeval ts; 

  double t;

  int err; 

  err = gettimeofday(&ts, NULL); 

  t = (double) (ts.tv_sec - starttime)  + (double) ts.tv_usec * 1.0e-6; 
 
  return t; 

}


