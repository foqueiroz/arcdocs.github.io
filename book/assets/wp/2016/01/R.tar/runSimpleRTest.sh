#!/bin/bash
# R submission script for the Leeds University HPC system
#       Written by Joanna Leng on 19th March 2015 
#
# Run in current working directory and use current environment
#
#$ -cwd -V
# Set a 5 min time limit
#$ -l h_rt=0:05:00
#Load R module
module load R
# run R using command file
# CMD BATCH flag should be given to suppress graphics
R CMD BATCH SimpleRTestScript.R