##### R script to try the Leeds University HPC system #####
#####   written by Joanna Leng on 11th March 2015     #####

# read in text data in a table format
myData <- read.table("SimpleRTestDataIn.txt",header=T,sep="\t")

# calculate the mean of each column
mean(myData$x)
mean(myData$y)
myData$x=myData$x^2

write.table(myData, file="SimpleRTestDataOut.txt", quote=FALSE, row.names=FALSE)
